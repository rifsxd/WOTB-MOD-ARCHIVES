************** Historical Tank Sights Project ***************

* Mod Info *

- Author : RifsxD
- Patch : 22:22 | 21.07.22
- Version : 1.0
- Current Nations : Germany - USSR
- Variants Count : Germany = 8 | USSR = 8

* Common Info *

- Configs Folder = Where ${TEXTURE_CONFIGS} stays i.e ( aim_camera-marker.txt.dvpl & aim_camera-marker_snipe.txt.dvpl )
- ${NATIONS} Folder = Where ${TEXTURES} stays i.e ( rxd_arcade.packed.webp & rxd_sniper.packed.webp )

* Instructions *

- Installation : 1 - Copy and Paste the ${TEXTURE_CONFIGS} to the folders $BLITZ_DATA_FOLDER/{Gfx & GFX2}/UI/BattleScreenHUD/{ PASTE HERE }
                 2 - Copy and Paste the ${TEXTURES} to the folders ${BLITZ_DATA_FOLDER}/(Gfx & Gfx2)/UI/BattleScreenHUD/{ PASTE HERE }