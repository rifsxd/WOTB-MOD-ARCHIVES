************************************************ Basic Info ****************************************************
- RxD Historical Gun Sounds ~
- Blitz Version: 8.5
- Mod Version: 1.5.5
- Historical Samples Version: 1.0 
- XML Config Version: 8.5.X
- Build Date & Time: 06:10 UTC+06 - 21/11/2021
- Author: RifsxD
- Guilded Server: https://www.guilded.gg/r/zzORL9m25l?i=dODw9xem

****************************************** Credentials *************************************************

                       Fully Edited, Compiled, & Built By Me " RifsxD "
   Resposting is "EXTREMELY" Prohibited, Do Not Repost or Reupload Elsewhere Without My Permission !

******************************************* Guide **************************************************

Installation Method: ---------------------------------------------------------------------------


		'(Windows Steam : c:\program files\Steam\SteamApps\common\World of Tanks Blitz
	          "or" c:\program files (x86)\Steam\SteamApps\common\World of Tanks Blitz 
                   (or whatever directory you installed your game)'
           
            ------------------------------------------------------------------------------------
              
           {                      
                               ---------------------------------------
               '(Android OS : {weapon.bnk.dvpl & weapon_basic.bnk.dvpl} >------/
                               ---------------------------------------         \
          /--------------------------------------------------------------------/
          \    
          /    
          \----> /Android/data/[blitz data folder]/packs/wwisesound/[copy - paste - overwrite]

          Uninstall Stock WoTB ---> Install - World of Tanks Blitz - RXD Edition
          
          },
           
*************************************** Changelogs *************************************

*** V-1.5.5 ~ 8.5 Patch ***

    - Added European Polish Tech Tree Heavies & Other Additional New Tanks.

*** V-1.5.3 ~ 8.3 Patch ***

    - RE:XML Fixed from V-1.5.1 for E100 & IS-7.

*** V-1.5.2 ~ 8.3 Patch ***

    - XML Fixed from V-1.5.1 for E100 & IS-7.


*** V-1.5.1 ~ 8.3 Patch ***

    - XML upstreamed to blitz patch 8.3,
     - SoundBankInfo.json upstreamed to blitz patch 8.3,
      - New additional tanks added (French & Hybrid),
       - First guilded migration exclusive update.

----------------------------------------------------

*** V-1.5 ~ 8.2 Patch ***

    - XML upstreamed to blitz patch 8.2,
     - Full Rock solid release with full modified XML Configs,
      - Nothing major changed in Wwise BNK,
       - First Open Android Release #1

-----------------------------------------


*** V-1.1 ~ 8.0 Patch ***

    - Additional tanks added,
     - semi-specific internal guns caliber sounds added,
      - 150mm - 183mm new cannonade and surrounding echo updated,
       - most bugs fixed,
        - some under-the-hood improvements.


--------------------------------------------


*** V-1.0 ~ 8.0 Patch ***

    - Open Release #1
